import React, {Component} from 'react';
class Home extends Component {
    render() {
	    return (
		<div className="row ">
	        <div className="medium-12 columns">
            
<nav id="menu" class="navbar navbar-default navbar-fixed-top">
  <div class="container"> 
    
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
      <a class="navbar-brand page-scroll" href="#page-top">Landscaper</a> </div>
    
    
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#about" class="page-scroll">About</a></li>
        <li><a href="#services" class="page-scroll">Services</a></li>
        <li><a href="#portfolio" class="page-scroll">Gallery</a></li>
        <li><a href="#testimonials" class="page-scroll">Testimonials</a></li>
        <li><a href="#contact" class="page-scroll">Contact</a></li>
      </ul>
    </div>
     
  </div>
   
</nav>

<header id="header">
  <div class="intro">
    <div class="overlay">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-md-offset-2 intro-text">
            <h1>Taller Allu Luna</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.<br/>
              Duis sed dapibus leo nec ornare diam.</p>
            <a href="#about" class="btn btn-custom btn-lg page-scroll">More Info</a> </div>
        </div>
      </div>
    </div>
  </div>
</header>

<div id="about">
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-md-6">
        <div class="about-text">
          <h2>Welcome to <span>Taller Allu Luna</span></h2>
          <hr/>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis sed dapibus leo nec ornare diam. Sed commodo nibh ante facilisis bibendum dolor feugiat at. Duis sed dapibus leo nec ornare diam commodo nibh.</p>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis sed dapibus leo nec ornare diam. Sed commodo nibh ante facilisis bibendum dolor feugiat at. Duis sed dapibus leo nec ornare diam commodo nibh.</p>
          <a href="#services" class="btn btn-custom btn-lg page-scroll">View All Services</a> </div>
      </div>
      <div class="col-xs-12 col-md-3">
        <div class="about-media"> <img src="img/taller_patio.jpg" alt=" "/> </div>
        <div class="about-desc">
          <h3>Servicios</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis sed dapibus leo nec ornare diam sedasd commodo nibh ante facilisis.</p>
        </div>
      </div>
      <div class="col-xs-12 col-md-3">
        <div class="about-media"> <img src="img/taller_patio2.jpg" alt=" "/> </div>
        <div class="about-desc">
          <h3>Mantenimiento</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis sed dapibus leo nec ornare diam sedasd commodo nibh ante.</p>
        </div>
      </div>
    </div>
  </div>
</div>

<div id="services">
  <div class="container">
    <div class="col-md-10 col-md-offset-1 section-title text-center">
      <h2>Our Services</h2>
      <hr/>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit duis sed dapibus leonec.</p>
    </div>
    <div class="row">
      <div class="col-md-3 text-center">
        <div class="service-media"> <img src="img/services/taller_patio3.jpg" alt=" "/> </div>
        <div class="service-desc">
          <h3>Revision Frenos</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis sed dapibus leo nec ornare diam sedasd commodo nibh ante facilisis bibendum dolor feugiat at.</p>
        </div>
      </div>
      <div class="col-md-3 text-center">
        <div class="service-media"> <img src="img/services/taller_patio4.jpg" alt=" "/> </div>
        <div class="service-desc">
          <h3>Cambio de Aceite</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis sed dapibus leo nec ornare diam sedasd commodo nibh ante facilisis bibendum dolor feugiat at.</p>
        </div>
      </div>
      <div class="col-md-3 text-center">
        <div class="service-media"> <img src="img/services/tecnico.jpg" alt=" "/> </div>
        <div class="service-desc">
          <h3>Alineacion</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis sed dapibus leo nec ornare diam sedasd commodo nibh ante facilisis bibendum dolor feugiat at.</p>
        </div>
      </div>
      <div class="col-md-3 text-center">
        <div class="service-media"> <img src="img/services/tecnico2.jpg" alt=" "/> </div>
        <div class="service-desc">
          <h3>Rotacion de Llantas</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis sed dapibus leo nec ornare diam sedasd commodo nibh ante facilisis bibendum dolor feugiat at.</p>
        </div>
      </div>
    </div>
  </div>
</div>

<div id="portfolio">
  <div class="container">
    <div class="section-title text-center center">
      <h2>Project Gallery</h2>
      <hr/>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit duis sed dapibus leonec.</p>
    </div>
    <div class="categories">
      <ul class="cat">
        <li>
          <ol class="type">
            <li><a href="#" data-filter="*" class="active">All</a></li>
            <li><a href="#" data-filter=".lawn">SERVICIOS</a></li>
            <li><a href="#" data-filter=".garden">AGENDA</a></li>
            <li><a href="#" data-filter=".planting">NOSOTROS</a></li>
          </ol>
        </li>
      </ul>
      <div class="clearfix"></div>
    </div>
    <div class="row">
      <div class="portfolio-items">
        <div class="col-sm-6 col-md-4 lawn">
          <div class="portfolio-item">
            <div class="hover-bg"> <a href="img/portfolio/taller1.jpg" title="Project Title" data-lightbox-gallery="gallery1">
              <div class="hover-text">
                <h4>Lorem Ipsum</h4>
              </div>
              <img src="img/portfolio/taller1.jpg" class="img-responsive" alt="Project Title"/> </a> </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-4 planting">
          <div class="portfolio-item">
            <div class="hover-bg"> <a href="img/portfolio/taller2.jpg" title="Project Title" data-lightbox-gallery="gallery1">
              <div class="hover-text">
                <h4>Adipiscing Elit</h4>
              </div>
              <img src="img/portfolio/taller2.jpg" class="img-responsive" alt="Project Title"/> </a> </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-4 lawn">
          <div class="portfolio-item">
            <div class="hover-bg"> <a href="img/portfolio/taller3.jpg" title="Project Title" data-lightbox-gallery="gallery1">
              <div class="hover-text">
                <h4>Lorem Ipsum</h4>
              </div>
              <img src="img/portfolio/taller3.jpg" class="img-responsive" alt="Project Title"/> </a> </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-4 lawn">
          <div class="portfolio-item">
            <div class="hover-bg"> <a href="img/portfolio/taller4.jpg" title="Project Title" data-lightbox-gallery="gallery1">
              <div class="hover-text">
                <h4>Lorem Ipsum</h4>
              </div>
              <img src="img/portfolio/taller4.jpg" class="img-responsive" alt="Project Title"/> </a> </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-4 planting">
          <div class="portfolio-item">
            <div class="hover-bg"> <a href="img/portfolio/taller5.jpg" title="Project Title" data-lightbox-gallery="gallery1">
              <div class="hover-text">
                <h4>Adipiscing Elit</h4>
              </div>
              <img src="img/portfolio/taller5.jpg" class="img-responsive" alt="Project Title"/> </a> </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-4 garden">
          <div class="portfolio-item">
            <div class="hover-bg"> <a href="img/portfolio/taller6.jpg" title="Project Title" data-lightbox-gallery="gallery1">
              <div class="hover-text">
                <h4>Dolor Sit</h4>
              </div>
              <img src="img/portfolio/taller6.jpg" class="img-responsive" alt="Project Title"/> </a> </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-4 garden">
          <div class="portfolio-item">
            <div class="hover-bg"> <a href="img/portfolio/taller7.jpg" title="Project Title" data-lightbox-gallery="gallery1">
              <div class="hover-text">
                <h4>Dolor Sit</h4>
              </div>
              <img src="img/portfolio/taller7.jpg" class="img-responsive" alt="Project Title"/> </a> </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-4 lawn">
          <div class="portfolio-item">
            <div class="hover-bg"> <a href="img/portfolio/taller8.jpg" title="Project Title" data-lightbox-gallery="gallery1">
              <div class="hover-text">
                <h4>Lorem Ipsum</h4>
              </div>
              <img src="img/portfolio/taller8.jpg" class="img-responsive" alt="Project Title"/> </a> </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-4 planting">
          <div class="portfolio-item">
            <div class="hover-bg"> <a href="img/portfolio/taller9.jpg" title="Project Title" data-lightbox-gallery="gallery1">
              <div class="hover-text">
                <h4>Adipiscing Elit</h4>
              </div>
              <img src="img/portfolio/taller9.jpg" class="img-responsive" alt="Project Title"/> </a> </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div id="testimonials" class="text-center">
  <div class="overlay">
    <div class="container">
      <div class="section-title">
        <h2>Testimonials</h2>
        <hr/>
      </div>
      <div class="row">
        <div class="col-md-10 col-md-offset-1">
          <div id="testimonial" class="owl-carousel owl-theme">
            <div class="item">
              <p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis sed dapibus leo nec ornare diam. Sed commodo nibh ante facilisis bibendum dolor feugiat at duis sed dapibus leo nec ornare diam."</p>
              <p>- John DOE, Parker County, TX</p>
            </div>
            <div class="item">
              <p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis sed dapibus leo nec ornare diam. Sed commodo nibh ante facilisis bibendum dolor feugiat at duis sed dapibus leo nec ornare diam."</p>
              <p>- Jenny DOE, Parker County, TX</p>
            </div>
            <div class="item">
              <p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis sed dapibus leo nec ornare diam. Sed commodo nibh ante facilisis bibendum dolor feugiat at duis sed dapibus leo nec ornare diam."</p>
              <p>- John DOE, Parker County, TX</p>
            </div>
            <div class="item">
              <p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis sed dapibus leo nec ornare diam. Sed commodo nibh ante facilisis bibendum dolor feugiat at duis sed dapibus leo nec ornare diam."</p>
              <p>- John DOE, Parker County, TX</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div id="contact" class="text-center">
  <div class="container">
    <div class="section-title text-center">
      <h2>Contact Us</h2>
      <hr/>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit duis sed dapibus leonec.</p>
    </div>
    <div class="col-md-10 col-md-offset-1 contact-info">
      <div class="col-md-4">
        <h3>Address</h3>
        <hr/>
        <div class="contact-item">
          <p>4321 California St,</p>
          <p>San Francisco, CA 12345</p>
        </div>
      </div>
      <div class="col-md-4">
        <h3>Working Hours</h3>
        <hr/>
        <div class="contact-item">
          <p>Monday-Saturday: 07:00 - 18:00</p>
          <p>Sunday: CLOSED</p>
        </div>
      </div>
      <div class="col-md-4">
        <h3>Contact Info</h3>
        <hr/>
        <div class="contact-item">
          <p>Phone: +1 123 456 1234</p>
          <p>Email: info@company.com</p>
        </div>
      </div>
    </div>
    <div class="col-md-8 col-md-offset-2">
      <h3>Leave us a message</h3>
      <form name="sentMessage" id="contactForm" novalidate>
        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <input type="text" id="name" class="form-control" placeholder="Name" required="required"/>
              <p class="help-block text-danger"></p>
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <input type="email" id="email" class="form-control" placeholder="Email" required="required"/>
              <p class="help-block text-danger"></p>
            </div>
          </div>
        </div>
        <div class="form-group">
          <textarea name="message" id="message" class="form-control" rows="4" placeholder="Message" required></textarea>
          <p class="help-block text-danger"></p>
        </div>
        <div id="success"></div>
        <button type="submit" class="btn btn-custom btn-lg">Send Message</button>
      </form>
    </div>
  </div>
</div>

<div id="footer">
  <div class="container text-center">
    <div class="col-md-8 col-md-offset-2">
      <div class="social">
        <ul>
          <li><a href="#"><i class="fa fa-facebook"></i></a></li>
          <li><a href="#"><i class="fa fa-twitter"></i></a></li>
          <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
        </ul>
      </div>
      <p>&copy; 2016 Landscaper. Designed by <a href="http://www.templatewire.com" rel="nofollow">TemplateWire</a></p>
    </div>
  </div>
</div>

            </div>
        </div>  
	     );
    }
}
export default Home;