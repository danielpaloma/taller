const express = require("express");
const router = express.Router();

const Servicio = require('../models/servicio')

router.get("/getServicios", async(req,res) => {

    try {
        const servicios = await Servicio.find({})
        return res.send(servicios);
    } catch (error) {
        return res.status(400).json({ message: error })
    }
    

});


router.post("/getServicioById", async(req,res) => {

    const idservicio = req.body.idservicio
    try {
        const servicio = await Servicio.findOne({_id : idservicio})
        console.log(servicio)
        return res.send(servicio);
    } catch (error) {
        return res.status(400).json({ message: error })
    }
    

});

module.exports = router;