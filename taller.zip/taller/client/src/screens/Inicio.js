import React, { useState, useEffect } from "react";

function Inicio() {





    return (
        <>
        <header className="bg-dark py-5">
            <div className="container px-5">
                <div className="row gx-5 justify-content-center">
                    <div className="col-lg-10">
                        <div className="text-center my-5">
                            <h1 className="display-5 fw-bolder text-white mb-2">Taller Allu Luna</h1>
                            <p className="lead text-white-50 mb-4">
                            Somos un taller de Mecánica Automotriz, contamos con 25 años de experiencia en el mercado automotriz y estamos catalogados entre los mejores talleres de mecánica automotriz. <br/>
                            Atendemos a nuestros clientes con el más alto nivel de servicio mecánico y humano, brindamos cumplimiento,
                            seguridad y calidad en nuestro trabajo para mantener tu vehículo en óptimas condiciones generándote la confianza que buscas.    
                            </p>
                            <div className="d-grid gap-3 d-sm-flex justify-content-sm-center">
                                <a className="btn btn-primary btn-lg px-4 me-sm-3" href="/servicios">Servicios</a>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <section className="py-5 border-bottom" id="features">
            <div className="container px-5 my-5">
                <div className="row gx-5">
                    <div className="col-lg-4 mb-5 mb-lg-0">
                        <div className="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i className="bi bi-collection"></i></div>
                        <h2 className="h4 fw-bolder">Experiencia</h2>
                        <p>Contamos con 25 años de experiencia en el mantenimiento y reparación de vehículos.</p>
                        
                    </div>
                    <div className="col-lg-4 mb-5 mb-lg-0">
                        <div className="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i className="bi bi-building"></i></div>
                        <h2 className="h4 fw-bolder">Certificación</h2>
                        <p>
                        Trabajamos bajo los parámetros establecidos por los diferentes fabricantes de vehículos automotores.
                        </p>
                        
                    </div>
                    <div className="col-lg-4">
                        <div className="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i className="bi bi-toggles2"></i></div>
                        <h2 className="h4 fw-bolder">Personal Calificado</h2>
                        <p>
                        Contamos con personal altamente calificado para los diferentes procesos y servicios prestados por nuestro taller.
                        </p>
                        
                    </div>
                </div>
            </div>

            <div className="container px-5 my-5">
                <div className="row gx-5">
                    <div className="col-lg-4 mb-5 mb-lg-0">
                        <div className="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i className="bi bi-collection"></i></div>
                        <h2 className="h4 fw-bolder">Atención Flexible</h2>
                        <p>Sabemos que tu tiempo es muy importante, por eso puedes agendar con anticipacion tu servicio.</p>
                        
                    </div>
                    <div className="col-lg-4 mb-5 mb-lg-0">
                        <div className="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i className="bi bi-building"></i></div>
                        <h2 className="h4 fw-bolder">Excelentes Precios</h2>
                        <p>Tu dinero es importante, por eso nosotros contamos con precios competitivos.</p>
                        
                    </div>
                    <div className="col-lg-4">
                        <div className="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i className="bi bi-toggles2"></i></div>
                        <h2 className="h4 fw-bolder">Calificación</h2>
                        <p>Con un puntaje de 4.8 en Google estamos catalogados dentro de los 10 mejores talleres.</p>
                        
                    </div>
                </div>
            </div>
        </section>

        
        
        </>

    )

}

export default Inicio;
