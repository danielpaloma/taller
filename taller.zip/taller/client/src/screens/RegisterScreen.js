import React, { useState, useEffect } from "react";

function RegisterScreen() {

    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [cpassword, setCpassword] = useState('');

    function register() {

        if (password == cpassword) {
            const user = {
                name,
                email,
                password,
                cpassword
            }

            console.log(user)


        } else {
            alert('Passwords no coinciden')
        }

    }

    return (
        <div>
            <div className="row justify-content-center mt-5">
                <div className="col-md-5">
                    <div className="bs">
                        <h1>Registro</h1>
                        <input type="text" className="form-control mt-10" placeholder="name"
                            value={name} onChange={(e) => { setName(e.target.value) }} />

                        <input type="text" className="form-control mt-10" placeholder="email"
                            value={email} onChange={(e) => { setEmail(e.target.value) }} />

                        <input type="text" className="form-control mt-10" placeholder="password"
                            value={password} onChange={(e) => { setPassword(e.target.value) }} />

                        <input type="text" className="form-control mt-10" placeholder="confirm password"
                            value={cpassword} onChange={(e) => { setCpassword(e.target.value) }} />

                        <button className="btn btn-primary mt-3" onClick={register}>Registrarse</button>

                    </div>
                </div>
            </div>

        </div>

    )

}

export default RegisterScreen;
