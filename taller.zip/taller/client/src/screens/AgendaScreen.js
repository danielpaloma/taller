import React, { useState } from "react";
import ReservaForm from "../components/ReservaForm";

function AgendaScreen() {

    return (

        <>

        <ReservaForm/>
        <hr/>
            <div className="col-lg-10 justify-content-center">
                <h1>Listado de Asignaciones</h1>
                <div>
                    <table className="table">
                        <thead className="thead-dark">
                            <tr>
                                <th scope="col">id</th>
                                <th scope="col">Fecha</th>
                                <th scope="col">Placa Vehiculo</th>
                                <th scope="col">Servicio</th>
                                <th scope="col">Mecanico</th>
                                <th scope="col">Estado</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th scope="row">1</th>
                                <td>01/12/2021</td>
                                <td>FGE485</td>
                                <td>Revision de frenos, pastillas, discos</td>
                                <td>Jhon Smith</td>
                                <td>Completado</td>
                            </tr>
                            <tr>
                                <th scope="row">2</th>
                                <td>02/12/2021</td>
                                <td>AEB791</td>
                                <td>Revision de suspension</td>
                                <td>Carlos Perez</td>
                                <td>Reservado</td>
                            </tr>
                            <tr>
                                <th scope="row">3</th>
                                <td>03/12/2021</td>
                                <td>WHT816</td>
                                <td>Revision de amortiguadores</td>
                                <td>Miguel Diaz</td>
                                <td>Reparado</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </>

    )

}

export default AgendaScreen;
