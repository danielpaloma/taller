import React from 'react';
import './App.css';
import Navbar from './components/Navbar';
import {BrowserRouter, Routes, Route, Link} from 'react-router-dom';
import Servicioscreen from './screens/Servicioscreen';
import ReservarScreen from './screens/ReservarScreen';
import RegisterScreen from './screens/RegisterScreen';
import LoginScreen from './screens/LoginScreen';
import Inicio from './screens/Inicio';
import Footer from './components/Footer';
import ReporteScreen from './screens/ReporteScreen';
import AgendaScreen from './screens/AgendaScreen';

function App() {
  return (
    <div className="App">
      <Navbar/>

      <BrowserRouter>

        <Routes>
          <Route path="/" element={ <Inicio/>}/>
          <Route path="/servicios" element={ <Servicioscreen/>}/>
          <Route path="/agenda" element={ <AgendaScreen/>}/>
          <Route path="/reservar/:idservicio" element={<ReservarScreen/>} />
          <Route path="/reportes" element={<ReporteScreen/>} />
          <Route path="/register" element={<RegisterScreen/>} />
          <Route path="/login" element={<LoginScreen/>} />
        </Routes>
        
      </BrowserRouter>

      <Footer/>
    
    </div>
  );
}

export default App;
