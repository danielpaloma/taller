import React, { useState } from "react";

function Success() {

    return (
        <div>

            <div class="alert alert-success" role="alert">
                Acción realizada Correctamente!
            </div>
        </div>

    )

}

export default Success;



