import React, { useState } from "react";

function Footer() {

    return (
        <footer class="py-5 bg-dark">
            <div class="container px-5"><p class="m-0 text-center text-white">Copyright &copy; MisionTIC 2021</p></div>
        </footer>

    )

}

export default Footer;
