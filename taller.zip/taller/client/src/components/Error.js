import React, { useState } from "react";

function Error() {

    return (
        <div>

            <div class="alert alert-danger" role="alert">
                Something went wrong. Please try again later.
            </div>
        </div>

    )

}

export default Error;