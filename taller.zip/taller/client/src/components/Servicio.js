import { useState } from 'react';
import { Modal, Button, Carousel } from 'react-bootstrap';
import {Link} from 'react-router-dom';

//recieves prop 'servicio' coming from Homescreen
function Servicio({ servicio }) {

    //modal pop-up HOOKS
    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);


    //front end
    return (




        <div className="row bs">

            <div className="col-md-4">
                <img src={servicio.imageUrls[0]} className="smallimg" />
            </div>

            <div className="col-md-7">
                <h1>{servicio.nombreServicio}</h1>
                <p>{servicio.descripcion}</p>
                <p>Costo: $ {servicio.costo}</p>
                <p>Duracion: {servicio.duracion} horas</p>
                <p>Disponible: {servicio.estado}</p>
            </div>

            <div style={{ float: "right" }}>
                <Link to={`/reservar/${servicio._id}`}>
                    <button className="btn btn-primary m-2">Reservar</button>
                </Link>

                <button className="btn btn-primary" onClick={handleShow}>
                    Ver Detalles
                </button>
            </div>

            {/* MODAL POP-UP */}

            <Modal show={show} onHide={handleClose} size='lg'>
                <Modal.Header>
                    <Modal.Title>{servicio.nombreServicio}</Modal.Title>
                </Modal.Header>

                {/* CAROUSEL images */}
                <Modal.Body>
                    <Carousel>

                        {servicio.imageUrls.map(url => {
                            return (
                                <Carousel.Item>
                                    <img
                                        className="d-block w-100 bigimg"
                                        src={url}
                                        
                                    />
                                </Carousel.Item>
                            )
                        })}



                    </Carousel>
                    <p>{servicio.descripcion}</p>
                </Modal.Body>

                <Modal.Footer>
                    <Button variant="primary" onClick={handleClose}>
                        Cerrar
                    </Button>
                </Modal.Footer>
            </Modal>

        </div>


    )

}

export default Servicio