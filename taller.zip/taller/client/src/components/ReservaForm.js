import React, { useState } from "react";

function ReservaForm() {

    return (
        <div className="row justify-content-center mt-5">
            <div className="col-md-10">
            <form >
                <div className="form-row">
                    <div className="form-group col-md-2">
                        <label for="fecha">Fecha</label>
                        <input type="text" className="form-control" id="fecha" placeholder="Fecha"/>
                    </div>
                    <div className="form-group col-md-2">
                        <label for="placa">Placa</label>
                        <input type="text" className="form-control" id="placa" placeholder="Placa"/>
                    </div>
                </div>
                <div className="form-group col-md-5">
                    <label for="servicio">Servicio</label>
                    <input type="text" className="form-control" id="servicio" placeholder="Servicio"/>
                </div>
                <div className="form-group col-md-5">
                    <label for="mecanico">Mecanico Asignado</label>
                    <input type="text" className="form-control" id="mecanico" placeholder="Mecanico Asignado"/>
                </div>
                <div className="form-row">
                    
                    <div className="form-group col-md-4">
                        <label for="estado">Estado</label>
                        <select id="estado" className="form-control">
                            <option selected>Choose...</option>
                            <option>...</option>
                        </select>
                    </div>
                    
                </div>
                
                <br/>
                <div>
                <button type="submit" className="btn btn-primary">Reservar</button>
                <button type="submit" className="btn btn-primary">Editar</button>
                <button type="submit" className="btn btn-primary">Cancelar</button>
                </div>
            </form>
            </div>

        </div>

    )

}

export default ReservaForm;
