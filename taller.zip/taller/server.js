const express = require("express");

const app = express();

const dbConfig = require('./db')

//to receive parameter in url
app.use(express.json())

//import servicios route
const servicioRoute = require('./routes/servicioRoute')


app.use('/api/servicios' , servicioRoute)


const port = process.env.PORT || 5000;
app.listen(port, ()=>console.log(`Node Server running on port ${port} with nodemon`));