import React, { useState } from 'react';

import 'antd/dist/antd.css';
import moment from 'moment';
//import './index.css';
import { DatePicker, TimePicker, Select, Space } from 'antd';

function PickerWithType({ type, onChange }) {
  if (type === 'time') return <TimePicker onChange={onChange} />;
  if (type === 'date') return <DatePicker onChange={onChange} />;
  return <DatePicker picker={type} onChange={onChange} />;
}


export default PickerWithType;
