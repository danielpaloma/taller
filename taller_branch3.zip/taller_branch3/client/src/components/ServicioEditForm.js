import React, { useState , useEffect} from 'react';
import { useParams } from "react-router-dom";
import axios from "axios"

function ServicioEditForm() {
    //servicio actual
    const {idservicio} = useParams()
    const[servicioActual,setServicioActual] = useState()

    //Servicio editado
    const [nombreServicio,setServicio]= useState()
    const [descripcion, setDescripcion]= useState()
    const [costo,setCosto]= useState()
    const [duracion,setDuracion]= useState()
    const [estado,setEstado]=useState(true)

    //1.capturar servicio actual
    useEffect(async()=>{
        try {
            //1.1 API request get item by id
            const data = (await axios.post('/api/servicios/getServicioById', {idservicio})).data
            setServicioActual(data)

            //console.log(data)

        } catch (error) {
            console.log(error)
        }

    }, [])



    //2. EDIT SERVICE
    async function editarServicio(){
        const servicioEditado = {
            idservicio,
            nombreServicio,
            descripcion,
            costo,
            duracion,
            estado
        }

        //console.log(servicio)

        try {
            const resp = await axios.put("/api/servicios/editarServicio",servicioEditado)
            console.log(resp)

            window.location.href='/servicios'
        } catch (error) {
            console.log(error)
        }
    }

    

    //front end
    return (

        <div className='container ml-2'>

            <h2>Editar Servicio</h2>

            <div className="form-group col-md-5">
                <label for="servicio">Nombre</label>
                <input type="text" className="form-control" id="nombreServicio"
                    onChange={(e) => { setServicio(e.target.value) }} />
            </div>

            <div className="form-group col-md-5">
                <label for="desc">Descripcion</label>
                <input type="text" className="form-control" id="descripcion"
                    onChange={(e) => { setDescripcion(e.target.value) }} />
            </div>

            <div className="form-group col-md-5">
                <label for="costo">Costo</label>
                <input type="text" className="form-control" id="costo"
                    onChange={(e) => { setCosto(e.target.value) }} />
            </div>

            <div className="form-group col-md-5">
                <label for="duracion">Duracion (horas)</label>
                <input type="number" className="form-control" id="duracion"
                    onChange={(e) => { setDuracion(e.target.value) }} />
            </div>

            <div >
                <button className="btn btn-primary m-2" onClick={editarServicio}>Guardar Cambios</button>
            </div>
        </div>
    )
}

export default ServicioEditForm