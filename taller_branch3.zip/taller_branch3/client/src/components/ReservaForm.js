import React, { useState } from "react";
import PickerWithType from "./PickerWithType";
import moment from "moment";
import {Space} from 'antd';
import axios from "axios";

function ReservaForm() {

    //1. variables to capture date and hour, and data from frontend
    const [fecha, setFecha] = useState();
    const [hora, setHora] = useState();
    const[placa,setPlaca] = useState();
    const[servicio,setServicio] = useState();
    const[mecanico,setMecanico] = useState();
    const[estado,setEstado] = useState();

    function guardarFecha(date) {
        
        setFecha(moment(date).format('DD-MM-YYYY'))
        console.log(fecha)
    }
    function guardarHora(date) {
        
        setHora(moment(date).format('hh:mm a'))
        console.log(hora)
    }

    async function reservarCita(){
        //2.Capture data from Form
        const datosReserva = {
            fecha,
            hora,
            placa,
            servicio,
            mecanico,
            estado
        }

        //3. Send data to backend API to save in DB
        try {
            const result = await axios.post('/api/citas/guardarCita', datosReserva)
        } catch (error) {
            
        }

    }

    return (
        <div className="row justify-content-center mt-5">
            <h2>Crear nueva Reserva</h2>
            <div className="col-md-10">
                <form >
                    <div className="form-row">
                        <div className="form-group col-md-5">
                            <label for="fecha">Seleccione Fecha: </label>
                            <div>
                                <Space>
                                    <PickerWithType type='date' onChange={guardarFecha} />
                                    <PickerWithType type='time' onChange={guardarHora} />
                                </Space>
                            </div>
                        </div>
                        <div className="form-group col-md-2">
                            <label for="placa">Placa</label>
                            <input type="text" className="form-control" id="placa" 
                            placeholder="Placa" onChange={(e) => { setPlaca(e.target.value) }} />
                        </div>
                    </div>
                    <div className="form-group col-md-5">
                        <label for="servicio">Servicio</label>
                        <input type="text" className="form-control" id="servicio" 
                        placeholder="Servicio" onChange={(e) => { setServicio(e.target.value) }} />
                    </div>
                    <div className="form-group col-md-5">
                        <label for="mecanico">Mecanico Asignado</label>
                        <input type="text" className="form-control" id="mecanico" 
                        placeholder="Mecanico Asignado" onChange={(e) => { setMecanico(e.target.value) }}/>
                    </div>
                    <div className="form-row">

                        <div className="form-group col-md-4">
                            <label for="estado">Estado</label>
                            <select id="estado" className="form-control" onChange={(e) => { setEstado(e.target.value) }}>
                                <option selected>Elegir...</option>
                                <option>Reservado</option>
                                <option>En reparacion</option>
                                <option>Reparado</option>
                                <option>Completado</option>
                                <option>Cancelado</option>
                            </select>
                        </div>

                    </div>

                    <br />
                    <div>
                        <button type="submit" className="btn btn-primary" onClick={reservarCita}>Reservar</button>
                    </div>
                </form>
            </div>

        </div>

    )

}

export default ReservaForm;
