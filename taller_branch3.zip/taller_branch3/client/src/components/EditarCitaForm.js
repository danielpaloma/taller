import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import PickerWithType from "./PickerWithType";
import moment from "moment";
import { Space } from 'antd';
import axios from "axios";



function EditarCitaForm() {
    //a. variables para la reserva actual
    const { idcita } = useParams()

    const [reservaActual, setReservaActual] = useState()

    //b . variables para la reserva editada
    //1. variables to capture date and hour, and data from frontend

    const [fecha, setFecha] = useState();
    const [hora, setHora] = useState();
    const [placa, setPlaca] = useState();
    const [servicio, setServicio] = useState();
    const [mecanico, setMecanico] = useState();
    const [estado, setEstado] = useState();

    function guardarFecha(date) {

        setFecha(moment(date).format('DD-MM-YYYY'))
        console.log(fecha)
    }
    function guardarHora(date) {

        setHora(moment(date).format('hh:mm a'))
        console.log(hora)
    }

    //1.capturar reserva actual
    useEffect(async () => {
        try {
            //1.1 API request get reserva by id
            const data = (await axios.post('/api/citas/getReservaById', { idcita })).data
            setReservaActual(data)

            //console.log(data)

        } catch (error) {
            console.log(error)
        }

    }, [])


    async function editarCita() {
        //capture data from Edit Form
        const citaEditada = {
            idcita,
            fecha,
            hora,
            placa,
            servicio,
            mecanico,
            estado
        }

        try {
            //backend query to update data
            const resp = await axios.put('/api/citas/editarCita', citaEditada)
            console.log(resp)
            window.location.href = '/agenda'

        } catch (error) {
            console.log(error)
        }
    }


    return (
        <>

            <div className="row justify-content-center mt-5">
                <div className="col-md-10 ml-3">
                    <h2>Editar Reserva</h2>
                    <div className="form-row">
                        <div className="form-group col-md-5">
                            <label for="fecha">Seleccione Fecha: </label>
                            <div>
                                <Space>
                                    <PickerWithType type='date' onChange={guardarFecha} />
                                    <PickerWithType type='time' onChange={guardarHora} />
                                </Space>
                            </div>
                        </div>
                        <div className="form-group col-md-2">
                            <label for="placa">Placa</label>
                            <input type="text" className="form-control" id="placa"
                                onChange={(e) => { setPlaca(e.target.value) }} />
                        </div>
                    </div>
                    <div className="form-group col-md-5">
                        <label for="servicio">Servicio</label>
                        <input type="text" className="form-control" id="servicio"
                            onChange={(e) => { setServicio(e.target.value) }} />
                    </div>
                    <div className="form-group col-md-5">
                        <label for="mecanico">Mecanico Asignado</label>
                        <input type="text" className="form-control" id="mecanico"
                            onChange={(e) => { setMecanico(e.target.value) }} />
                    </div>
                    <div className="form-row">

                        <div className="form-group col-md-4">
                            <label for="estado">Estado</label>
                            <select id="estado" className="form-control"
                                onChange={(e) => { setEstado(e.target.value) }}>
                                <option selected>Elegir...</option>
                                <option>Reservado</option>
                                <option>En reparacion</option>
                                <option>Reparado</option>
                                <option>Completado</option>
                                <option>Cancelado</option>
                            </select>
                        </div>

                    </div>

                    <br />
                    <div>
                        <button className="btn btn-primary" onClick={editarCita}>Guardar</button>
                        
                    </div>

                </div>

            </div>
        </>

    )
}

export default EditarCitaForm