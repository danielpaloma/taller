import React, { useState } from 'react';
import axios from "axios"

function ServicioForm() {

    const [nombreServicio,setServicio]= useState()
    const [descripcion, setDescripcion]= useState()
    const [costo,setCosto]= useState()
    const [duracion,setDuracion]= useState()
    const [estado,setEstado]=useState(true)

    //1.ADD SERVICE
    async function addService(){
        const servicio = {
            nombreServicio,
            descripcion,
            costo,
            duracion,
            estado
        }

        //console.log(servicio)

        try {
            const result = await axios.post('/api/servicios/nuevoServicio', servicio).data

            //clean fields after saving data
            setServicio()
            setDescripcion()
            setCosto()
            setDuracion()
            setEstado()

            window.location.href='/servicios'
        } catch (error) {
            console.log(error)
        }
    }

    

    //front end
    return (

        <div className='container ml-2'>

            <h2>Agregar Nuevo Servicio</h2>

            <div className="form-group col-md-5">
                <label for="servicio">Nombre</label>
                <input type="text" className="form-control" id="nombreServicio"
                    onChange={(e) => { setServicio(e.target.value) }} />
            </div>

            <div className="form-group col-md-5">
                <label for="desc">Descripcion</label>
                <input type="text" className="form-control" id="descripcion"
                    onChange={(e) => { setDescripcion(e.target.value) }} />
            </div>

            <div className="form-group col-md-5">
                <label for="costo">Costo</label>
                <input type="text" className="form-control" id="costo"
                    onChange={(e) => { setCosto(e.target.value) }} />
            </div>

            <div className="form-group col-md-5">
                <label for="duracion">Duracion (horas)</label>
                <input type="number" className="form-control" id="duracion"
                    onChange={(e) => { setDuracion(e.target.value) }} />
            </div>

            <div >
                <button className="btn btn-primary m-2" onClick={addService}>Guardar</button>
            </div>
        </div>
    )
}

export default ServicioForm