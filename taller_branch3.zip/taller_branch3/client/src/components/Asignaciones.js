import { useState, useEffect } from 'react';
import { Modal, Button, Carousel } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { Tag, Divider } from 'antd';
import Loader from "./Loader";
import Error from "./Error";
import Swal from 'sweetalert2'
import axios from "axios";

//recieves prop 'task' coming from ProfileScreen
function Asignaciones({ task }) {

    
    
    const [loading, setLoading] = useState()
    const [error, setError] = useState()


    //capturar reserva actual
    const idreserva = task._id;
    const fecha = task.fecha;
    const hora = task.hora;
    const placa = task.placa;
    const servicio = task.servicio;
    const mecanico = task.mecanico;
    const [estado, setEstado] = useState();
    
    //console.log(estado)
    

    //modal pop-up HOOKS
    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);


    

    //Funcion Boton Actualizar Estado
    async function actualizarEstado() {

        const citaEditada ={
            idreserva,
            fecha,
            hora,
            placa,
            servicio,
            mecanico,
            estado
        }

        try {
            setLoading(true)
            const result = await axios.put("/api/citas/editarEstadoCita", citaEditada)
            console.log(result)
            setLoading(false)
            Swal.fire('Estado Actualizado', 'Estado de cita fue actualizado', 'success').then(
                result => { window.location.reload() }
            )
        } catch (error) {
            console.log(error)
            setLoading(false)
            Swal.fire('Oops', 'Something went wrong', 'error')
        }
    }


    //front end
    return (

        <div className="row bs">



            <div className="col-md-7">
                <h1>{task.servicio}</h1>
                <p><b>Fecha:</b> {task.fecha}</p>
                <p><b>Hora:</b> {task.hora}</p>
                <p><b>Placa:</b> {task.placa}</p>
                <p><b>Estado:</b> {task.estado == 'Cancelado' ? (<Tag color="orange">Cancelado</Tag>) : <Tag color="green">{task.estado}</Tag>}</p>

                {/* EDITAR ESTADO DE LA ASIGNACION */}
                <div className="form-group col-md-4">
                    <label for="estado">Editar Estado</label>
                    <select id="estado" className="form-control"
                        onChange={(e) => { setEstado(e.target.value) }}>
                        <option selected>Elegir...</option>
                        <option>Reservado</option>
                        <option>En reparacion</option>
                        <option>Reparado</option>
                        <option>Completado</option>
                        
                    </select>
                </div>

                <div className='text-left'>
                    {/* <Link to={`/reservar/${servicio._id}`}> */}
                    <button className="btn btn-primary m-2"
                    onClick={actualizarEstado}>
                        Actualizar Estado
                    </button>
                    {/* </Link> */}
                </div>

            </div>



        </div>
    )

}

export default Asignaciones