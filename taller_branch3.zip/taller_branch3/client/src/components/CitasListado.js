import React, { useState, useEffect } from "react";
import axios from "axios";
import Swal from 'sweetalert2'
//import Servicio from "./Servicio";
import Loader from "./Loader";
import Error from "./Error";
import { Link } from 'react-router-dom';
import { Tag, Divider } from 'antd';


function CitasListado({ fecha }) {

    //Receives 'fecha' value from AgendaScreen
    //TODO: implement filter by date using 'fecha' value.
    //console.log(fecha)


    //2.If data received from backend --> update state and render 'citas'
    //variable 'citas' stores data from backend
    const [citas, setCitas] = useState([])


    const [loading, setLoading] = useState()
    const [error, setError] = useState()


    //1.Bring data from backend (citas)
    useEffect(async () => {
        try {
            setLoading(true)

            //1.1 API Request
            const data = (await axios.get('/api/citas/getCitas')).data
            setCitas(data)
            //console.log(data)

            setLoading(false)

        } catch (error) {

            setError(true)
            console.log(error)
            setLoading(false)
        }

    }, [])

    //Funcion Boton Cancelar
    async function cancelarCita(citaid) {

        try {
            setLoading(true)
            const result = await (await axios.post("/api/citas/cancelarCita", { citaid })).data
            console.log(result)
            setLoading(false)
            Swal.fire('Cita cancelada', 'Esta cita fue cancelada', 'success').then(
                result => { window.location.reload() }
            )
        } catch (error) {
            console.log(error)
            setLoading(false)
            Swal.fire('Oops', 'Something went wrong', 'error')
        }
    }

    //Boton Eliminar Reserva
    //3. DELETE ITEM
    async function eliminarReserva(deleteReservaId){
        //console.log('Eliminar este id:', deleteReservaId)

        try {
            const resp = await axios.delete(`/api/citas/deleteReserva/${deleteReservaId}`)
            console.log(resp)
            window.location.href = '/agenda'
        } catch (error) {
            console.log(error)
        } 
    }


    return (
        <div className="container">

            <div className="row justify-content-center mt-5">
                {loading ? (<h1> <Loader /></h1>) : (
                    <>
                        <table className="table">
                            <thead className="thead-dark">
                                <tr>
                                    {/* <th scope="col">id</th> */}
                                    <th scope="col">Fecha</th>
                                    <th scope="col">Hora</th>
                                    <th scope="col">Placa Vehiculo</th>
                                    <th scope="col">Servicio</th>
                                    <th scope="col">Mecanico</th>
                                    <th scope="col">Estado</th>
                                </tr>
                            </thead>

                            {
                                citas.length >= 1 ?
                                    (citas.map(cita => {
                                        return (
                                            <tbody>
                                                <tr>
                                                    {/* <th scope="row">{cita._id}</th> */}
                                                    <td>{cita.fecha}</td>
                                                    <td>{cita.hora}</td>
                                                    <td>{cita.placa}</td>
                                                    <td>{cita.servicio}</td>
                                                    <td>{cita.mecanico}</td>
                                                    <td>{cita.estado == 'Cancelado' ? (<Tag color="orange">Cancelado</Tag>) : <Tag color="green">{cita.estado}</Tag>}</td>
                                                    <td>
                                                        <Link to={`/editarCita/${cita._id}`}>
                                                            <button className="btn btn-primary m-2">Editar</button>
                                                        </Link>
                                                    </td>

                                                    {(cita.estado !== 'Cancelado') && (
                                                        <td>
                                                            <button className="btn btn-primary m-2" onClick={() => { cancelarCita(cita._id) }}>Cancelar</button>
                                                        </td>
                                                    )}

                                                    <td>
                                                        <button className="btn btn-primary m-2" 
                                                        onClick={()=>{eliminarReserva(cita._id)}}>
                                                            Eliminar
                                                            </button>
                                                    </td>


                                                </tr>
                                            </tbody>
                                        )
                                    }))

                                    : (<Error />)
                            }
                        </table>
                    </>)


                }

            </div>

        </div >
    )

}

export default CitasListado;