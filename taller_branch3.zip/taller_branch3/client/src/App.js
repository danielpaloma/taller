import React from 'react';
import './App.css';
import Navbar from './components/Navbar';
import {BrowserRouter, Routes, Route, Link} from 'react-router-dom';
import Servicioscreen from './screens/Servicioscreen';
import ReservarScreen from './screens/ReservarScreen';
import RegisterScreen from './screens/RegisterScreen';
import LoginScreen from './screens/LoginScreen';
import Inicio from './screens/Inicio';
import Footer from './components/Footer';
import ReporteScreen from './screens/ReporteScreen';
import AgendaScreen from './screens/AgendaScreen';
import EditarCitaForm from './components/EditarCitaForm';
import ProfileScreen from './screens/ProfileScreen';
import AdminScreen from './screens/AdminScreen';
import ReservaForm from './components/ReservaForm';
import ServicioForm from './components/ServicioForm';
import ServicioEditForm from './components/ServicioEditForm';
import ServiciosPage from './screens/ServiciosPage';
import Contacto from './screens/Contacto';
import Nosotros from './screens/Nosotros';

function App() {
  return (
    <div className="App">
      <Navbar/>

      <BrowserRouter>

        <Routes>
          <Route path="/" element={ <Inicio/>}/>
          <Route path="/ServiciosPage" element={<ServiciosPage/>} />
          <Route path="/contacto" element={<Contacto/>} />
          <Route path="/nosotros" element={<Nosotros/>} />


          <Route path="/servicios" element={ <Servicioscreen/>}/>
          <Route path="/agregarServicio" element={<ServicioForm/>}/>
          <Route path="/reservar/:idservicio" element={<ReservarScreen/>} />
          <Route path="/editarServicio/:idservicio" element={<ServicioEditForm/>} />

          <Route path="/agenda" element={ <AgendaScreen/>}/>
          <Route path="/agregarCita" element={<ReservaForm/>} />
          <Route path="/editarCita/:idcita" element={<EditarCitaForm/>}/>

          <Route path="/reportes" element={<ReporteScreen/>} />

          <Route path="/register" element={<RegisterScreen/>} />
          <Route path="/login" element={<LoginScreen/>} />
          <Route path="/profile" element={<ProfileScreen/>}/>
          <Route path="/admin" element={<AdminScreen/>}/>
          
        </Routes>
        
      </BrowserRouter>

      <Footer/>
    
    </div>
  );
}

export default App;
