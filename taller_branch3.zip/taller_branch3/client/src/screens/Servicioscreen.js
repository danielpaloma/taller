import React, { useState, useEffect } from "react";
import axios from "axios";
import Servicio from "../components/Servicio";
import Loader from "../components/Loader";
import Error from "../components/Error";
import {Link} from 'react-router-dom';
function Servicioscreen() {

    //1.1.If data received from backend --> update state and render 'servicios'
    //variable 'servicios' stores data from backend
    const [servicios, setServicios] = useState([])


    const [loading, setLoading] = useState()
    const [error, setError] = useState()


    //1.0 READ all Services : Bring data from backend (servicios)
    useEffect(async () => {
        try {
            setLoading(true)

            //1.1 API Request
            const data = (await axios.get('/api/servicios/getServicios')).data
            setServicios(data)
            //console.log(data)

            setLoading(false)

        } catch (error) {

            setError(true)
            console.log(error)
            setLoading(false)
        }

    }, [])



    return (
        <div className="container">
            <h2>Gestion de Servicios</h2>
            <Link to={'/agregarServicio'}>
                <button className="btn btn-primary">Agregar nuevo Servicio</button>
            </Link>

            <div className="row justify-content-center mt-5">

                {loading ? (<h1> <Loader /></h1>) :
                    servicios.length > 1 ?
                        (servicios.map(servicio => {
                            return (
                                <div className="col-md-9 mt-2">
                                    <Servicio servicio={servicio} />

                                </div>
                            )
                        }))
                        : (<Error />)

                }

            </div>

        </div>
    )

}

export default Servicioscreen;