import React, { useState, useEffect } from "react";
import axios from "axios"
import Loader from "../components/Loader";
import Error from "../components/Error";
import Success from "../components/Success";

function RegisterScreen() {

    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [cpassword, setCpassword] = useState('');

    const [loading, setLoading] = useState(false);
    const [error, setError] = useState();
    const[success, setSuccess] = useState();

    async function register() {

        if (password == cpassword) {
            const user = {
                name,
                email,
                password,
                cpassword
            }

            try {
                setLoading(true)
                //send user data to api backend
                const result = await axios.post('/api/users/register', user).data
                setLoading(false)
                setSuccess(true)

                //After saving user data successfully, delete form fields
                setName('')
                setEmail('')
                setPassword('')
                setCpassword('')

            } catch (error) {
                console.log(error)
                setLoading(false)
                setError(true)
            }


        } else {
            alert('Passwords no coinciden')
        }

    }

    return (
        <div>

            {loading && (<Loader/>)}
            {error && (<Error/>)}


            <div className="row justify-content-center mt-5">
                <div className="col-md-5">
                {success && (<Success message='Registration successful'/>)}

                    <div className="bs">
                        <h1>Registro</h1>
                        <input type="text" className="form-control mt-10" placeholder="name"
                            value={name} onChange={(e) => { setName(e.target.value) }} />

                        <input type="text" className="form-control mt-10" placeholder="email"
                            value={email} onChange={(e) => { setEmail(e.target.value) }} />

                        <input type="text" className="form-control mt-10" placeholder="password"
                            value={password} onChange={(e) => { setPassword(e.target.value) }} />

                        <input type="text" className="form-control mt-10" placeholder="confirm password"
                            value={cpassword} onChange={(e) => { setCpassword(e.target.value) }} />

                        <button className="btn btn-primary mt-3" onClick={register}>Registrarse</button>

                    </div>
                </div>
            </div>

        </div>

    )

}

export default RegisterScreen;
