import React, { useState, useEffect } from "react";
import Loader from "../components/Loader";
import Error from "../components/Error";
import axios from "axios";

function UsersListScreen() {

    const [usersList, setUsersList] = useState([])

    const [loading, setLoading] = useState()
    const [error, setError] = useState()

    useEffect(async()=>{
        try {
            setLoading(true)
            const data = (await axios.get('/api/users/getAllUsers')).data
            setUsersList(data)
            setLoading(false)
        } catch (error) {
            console.log(error)
            setLoading(false)
            setError(true)
        }
    }, [])

    

    return (
        <div className="container">

            <div className="row justify-content-center mt-5">
                {loading ? (<h1> <Loader /></h1>) : (
                    <>
                        <table className="table">
                            <thead className="thead-dark">
                                <tr>
                                    {/* <th scope="col">id</th> */}
                                    <th scope="col">Nombre</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">isAdmin</th>
                                </tr>
                            </thead>

                            {
                                usersList.length >= 1 ?
                                    (usersList.map(userData => {
                                        return (
                                            <tbody>
                                                <tr>
                                                    <td>{userData.name}</td>
                                                    <td>{userData.email}</td>
                                                    <td>{userData.isAdmin == false ? 'NO' : 'SI' }</td>

                                                </tr>
                                            </tbody>
                                        )
                                    }))

                                    : (<Error />)
                            }
                        </table>
                    </>)


                }

            </div>

        </div >

    )

}

export default UsersListScreen;



