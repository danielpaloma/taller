import React, { useState } from "react";

function ReporteScreen() {

    return (

        <>
            <section>
                <div className="row">
                    <div className="col-lg-3 col-md-6 mb-4">
                        <div className="card">
                            <div className="card-body">
                                <p className="text-uppercase small mb-2">
                                    <strong>Servicio más solicitado</strong>
                                </p>
                                <p>Revision de frenos, pastillas, discos</p>
                                <h5 className="mb-0">
                                    <strong>25</strong>
                                    <small className="text-success ms-2">
                                        <i className="fas fa-arrow-up fa-sm pe-1"></i>13,48%</small>
                                </h5>

                                <hr />

                                <p className="text-uppercase text-muted small mb-2">
                                    Periodo anterior
                                </p>
                                <h5 className="text-muted mb-0">11</h5>
                            </div>
                        </div>
                        
                    </div>

                    <div className="col-lg-3 col-md-6 mb-4">
                        <div className="card">
                            <div className="card-body">
                                <p className="text-uppercase small mb-2">
                                    <strong>Servicio menos solicitado</strong>
                                </p>
                                <p>Cambio de aceite</p>
                                <h5 className="mb-0">
                                    <strong>4</strong>
                                    <small className="text-danger ms-2">
                                        <i className="fas fa-arrow-down fa-sm pe-1"></i>23,58%</small>
                                </h5>

                                <hr />

                                <p className="text-uppercase text-muted small mb-2">
                                    Periodo anterior
                                </p>
                                <h5 className="text-muted mb-0">7</h5>
                            </div>
                        </div>
                    </div>

                    <div className="col-lg-3 col-md-6 mb-4">
                        <div className="card">
                            <div className="card-body">
                                <p className="text-uppercase small mb-2">
                                    <strong>Servicios Completados</strong>
                                </p>
                                <h5 className="mb-0">
                                    <strong>123</strong>
                                    <small className="text-success ms-2">
                                        <i className="fas fa-arrow-down fa-sm pe-1"></i>85,58%</small>
                                </h5>

                                

                                
                            </div>
                        </div>
                    </div>

                    
                </div>
            </section>

            <section>
                <div className="row">
                    

                    <div className="col-md-4 mb-4">
                        <div className="card mb-4">
                            <div className="card-body">
                                <p className="text-center"><strong>Listado de mecanicos</strong></p>
                                <div id="pie-chart-current"></div>
                            </div>
                        </div>

                        <div className="card">
                            <div className="card-body">
                                <p className="text-center"><strong>Asignaciones</strong></p>
                                <div id="pie-chart-previous"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

        </>

    )

}

export default ReporteScreen;
