import React, { useState } from "react";

function Contacto() {

    return (
        <div className="container ml-2">
            <h1>Contactenos</h1>
            <p>Llama ahora para agendar tu reserva y atenderte con gusto en nuestro Taller de Mecánica</p>

            <p><b>Telefono:</b> 310 2267894 / 321 4567891</p>
            <p><b>Email:</b> tallerLuna@luna.com</p>
            <p><b>Direccion:</b> Carrera 30 # 6-48 Bogota</p>
        </div>

    )

}

export default Contacto;



