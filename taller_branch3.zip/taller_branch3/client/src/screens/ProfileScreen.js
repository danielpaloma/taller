import React, { useState, useEffect } from "react";
import { Tabs } from 'antd';
import axios from 'axios'
import { Link } from 'react-router-dom';

import Loader from "../components/Loader";
import Error from "../components/Error";
import Asignaciones from "../components/Asignaciones";

const { TabPane } = Tabs;

function ProfileScreen() {

    const user = JSON.parse(localStorage.getItem("currentUser"))

    useEffect(
        () => {
            if (!user) {
                window.location.href = '/login'
            }


        }, []
    )

    return (

        <div className="ml-3 mt-3">
            <Tabs defaultActiveKey="1" >
                <TabPane tab="Asignaciones" key="1">
                    <MisAsignaciones />
                </TabPane>
                <TabPane tab="Perfil" key="2">
                    <h1>Mi perfil</h1>
                    <br />
                    <h1>Nombre : {user.name}</h1>
                    <h1>Email : {user.email}</h1>
                    <h1>isAdmin : {user.isAdmin ? 'SI' : 'NO'}</h1>
                    {user.isAdmin && (
                        <Link to={`/admin`}>
                            <button className="btn btn-primary m-2">Ir a Admin Panel</button>
                        </Link>
                    )}
                </TabPane>


            </Tabs>

        </div>

    )
}


export default ProfileScreen


export function MisAsignaciones() {

    const [loading, setLoading] = useState()
    const [error, setError] = useState()

    const user = JSON.parse(localStorage.getItem("currentUser"))
    const [asignaciones, setAsignaciones] = useState([])

    useEffect(
        async () => {

            try {
                setLoading(true)

                const data = (await axios.post('/api/citas/getCitaByUserName', { mecanico: user.name })).data
                console.log(data)
                setAsignaciones(data)

                setLoading(false)
            } catch (error) {
                console.log(error)
                setLoading(false)
                setError(true)
            }


        }, [])

    return (
        <div className="container">

            <h2>Listado de Asignaciones</h2>

            <div className="row justify-content-center mt-5">
                {loading ? (<h1> <Loader /></h1>) :
                    asignaciones.length >= 1 ?
                        (asignaciones.map(task => {
                            return (
                                <div className="col-md-9 mt-2">
                                    <Asignaciones task={task} />

                                </div>
                            )
                        }))
                        : (<Error />)
                }

            </div>

        </div>
    )
}