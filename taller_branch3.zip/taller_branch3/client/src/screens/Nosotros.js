import React, { useState } from "react";

function Nosotros() {

    return (
        <div className="container ml-2">
            

            <div>
                <h1>Nosotros</h1>
                <h3>Misión</h3>
                <p>Taller Allu Luna. Para nosotros es muy grato poner a su disposición y consideración nuestro taller, nuestra experiencia y equipo de profesionales para el mantenimiento preventivo 
                    y correctivo de automóviles, camionetas y camperos de todas las marcas. Disponemos de 800 m2, tecnología de punta, equipos de alta precisión, con nuestra experiencia y 
                    equipo de profesionales, estamos seguros de ofrecer soluciones oportunas y confiables a las necesidades de mantenimiento de su vehículo.</p>

                <h2>Visión</h2>
                <p>Dar al cliente el mejor servicio,variedad, calidad y valor de productos, respetando la seguridad y salud de nuestros colaboradores y el medio ambiente, es nuestra prioridad.</p>

                <h2>Valores</h2>
                <p>
                Nos comprometemos ante nuestros clientes a mejorar continuamente nuestros servicios con elevados estándares de calidad, confiabilidad y responsabilidad. 
                Nunca comprometemos la calidad de nuestros servicios con el fin de reducir costos.
                Suministramos a nuestros clientes información oportuna y veraz sobre las condiciones y características de los servicios que prestamos.
                Todas nuestras campañas y publicidad están ajustadas a la realidad. Protegemos la información de nuestros clientes de acuerdo a nuestra política de protección de datos personales. 
                </p>

            </div>

            
        </div>

    )

}

export default Nosotros;



