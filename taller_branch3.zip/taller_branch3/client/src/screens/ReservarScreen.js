import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import axios from 'axios';
import Loader from "../components/Loader";
import Error from "../components/Error";

function ReservarScreen() {

    //capture idservicio from URL
    const { idservicio } = useParams()
    //console.log({idservicio})

    const [loading, setLoading] = useState(true);
    const [error, setError] = useState();

    //to retrieve data 'servicio' from DB
    const [servicio, setServicio] = useState();

    useEffect(async () => {
        try {
            setLoading(true)

            //1.1 API Request : sending idservicio to query backend
            const data = (await 
                axios.post('/api/servicios/getServicioById',
                { idservicio })).data
            
            setServicio(data) //store data from DB to frontend
            console.log(data)

            setLoading(false)
        } catch (error) {
            setLoading(false)
            setError(true)
        }

    }, [])

    return (
        <div>
            
            {loading ? (<Loader/>): servicio ?
                (<div>
                    <div className="row">
                        <div className="col-md-5">
                            <h1>{servicio.nombreServicio}</h1>
                            <img src={servicio.imageUrls[0]} className='bigimg'/>
                        </div>

                        <div className="col-md-5">

                            <div>
                            <h1>Detalles Reserva</h1>
                            <hr/>
                            <p>Fecha: </p>
                            <p>Descripcion: {servicio.descripcion}</p>
                            <p>Duracion: {servicio.duracion} hora(s)</p>
                            <p>Estado: {servicio.estado ? 'Disponible':'No disponible'} </p>
                            <hr/>
                            </div>
                                <p>Costo: ${servicio.costo}</p>
                            <div>

                            <div>
                                <button className='btn btn-primary'>Pagar</button>
                            </div>

                            </div>

                        </div>

                    </div>
                </div>)
                : (<Error/>)
            }

        </div>
    )

}

export default ReservarScreen;