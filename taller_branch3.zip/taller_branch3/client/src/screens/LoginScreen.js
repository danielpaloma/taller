import React, { useState, useEffect } from "react";
import axios from "axios"
import Loader from "../components/Loader";
import Error from "../components/Error";
import Success from "../components/Success";

function LoginScreen() {


    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const [loading, setLoading] = useState(false);
    const [error, setError] = useState();
    //const[success, setsuccess]=useState(false)  


    async function login() {
        const user = {
            email,
            password,
        }

        try {
            setLoading(true)
            //send user data to backend
            const result = await (await axios.post('/api/users/login', user)).data
            setLoading(false)

            localStorage.setItem('currentUser', JSON.stringify(result));
            //if user logged in successfully--> navigate to home
            
            window.location.href = '/profile'
            //console.log(result)

            
        } catch (error) {
            console.log(error)
            setLoading(false)
            setError(true)
            
            
        }

    }

    return (
        <div>
            {loading && (<Loader/>)}
            <div className="row justify-content-center mt-5">
                <div className="col-md-5">
                    {error && (<Error message='Invalid Credentials'/>)}
                    <div className="bs">
                        <h1>Login</h1>
                        <input type="text" className="form-control mt-10" placeholder="email"
                            value={email} onChange={(e) => { setEmail(e.target.value) }} />

                        <input type="text" className="form-control mt-10" placeholder="password"
                            value={password} onChange={(e) => { setPassword(e.target.value) }} />

                        <button className="btn btn-primary mt-3" onClick={login}>Login</button>

                    </div>
                </div>
            </div>

        </div>

    )

}

export default LoginScreen;
