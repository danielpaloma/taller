import React, { useState } from "react";
import ReservaForm from "../components/ReservaForm";
import CitasListado from "../components/CitasListado";
import PickerWithType from "../components/PickerWithType";
import moment from "moment";

import {Space} from 'antd';

import {Link} from 'react-router-dom';

function AgendaScreen() {

    //2. set the 'fecha' value
    //PickerWithType returns DatePicker
    //DatePicker returns an object 'date'
    function filterByDate(date) {
        
        setFecha(moment(date).format('DD-MM-YYYY'))
        //console.log(fecha)
    }

    //1. variables to capture date and hour from frontend
    const [fecha, setFecha] = useState();
    //const [hora, setHora] = useState();


    return (

        <>

            <div className="col-lg-10 justify-content-center">
                <h1>Listado de Asignaciones</h1>
                <Link to={'/agregarCita'}>
                <button className="btn btn-primary m-2">Agregar una Reserva </button>
                </Link>
                <hr/>
                <div>
                    <div>Filtrar por fecha</div>
                    <Space>
                        <PickerWithType type='date' onChange={filterByDate} />
                    </Space>
                </div>
                

            </div>
            {/*3. Sending variable 'fecha' to CitasListado as prop  */}
            <div>
                <CitasListado fecha={fecha}/>
            </div>
        </>

    )

}

export default AgendaScreen;
