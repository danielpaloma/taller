import React, { useState, useEffect } from "react";
import axios from "axios";
import Servicio from "../components/Servicio";
import Loader from "../components/Loader";
import Error from "../components/Error";
import { Link } from 'react-router-dom';

function ServiciosPage() {


    const [servicios, setServicios] = useState([])


    const [loading, setLoading] = useState()
    const [error, setError] = useState()

    //1.0 READ all Services : Bring data from backend (servicios)
    useEffect(async () => {
        try {
            setLoading(true)

            //1.1 API Request
            const data = (await axios.get('/api/servicios/getServicios')).data
            setServicios(data)
            //console.log(data)

            setLoading(false)

        } catch (error) {

            setError(true)
            console.log(error)
            setLoading(false)
        }

    }, [])

    return (
        <div className="container ml-2">

            <h1>Nuestros Servicios</h1>

            <div className="row justify-content-center mt-5">

                {loading ? (<h1> <Loader /></h1>) :
                    servicios.length > 1 ?
                        (servicios.map(servicio => {
                            return (

                                <div className="col-md-9 mt-2">
                                    <div className="bs">
                                        <div className="col-md-7">
                                            <h1>{servicio.nombreServicio}</h1>
                                            <p>{servicio.descripcion}</p>
                                            <p>Costo: $ {servicio.costo}</p>
                                            <p>Duracion: {servicio.duracion} horas</p>
                                            <p>Disponible: {servicio.estado ? 'Disponible' : 'No disponible'}</p>
                                            <Link to={`/contacto`}>
                                                <button className="btn btn-primary m-2">Reserva Ahora!</button>
                                            </Link>
                                        </div>

                                    </div>
                                </div>
                            )
                        }))
                        : (<Error />)

                }

            </div>


        </div>

    )

}

export default ServiciosPage;



