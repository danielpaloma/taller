import React, { useState, useEffect } from "react";
import { Tabs } from 'antd';
import Servicioscreen from "./Servicioscreen";
import AgendaScreen from "./AgendaScreen";
import ReporteScreen from "./ReporteScreen";
import UsersListScreen from "./UsersListScreen";

function AdminScreen() {

    const user = JSON.parse(localStorage.getItem("currentUser"))

    useEffect(
        () => {
            // if user is not admin -> navigate to 'home'
            if (!user.isAdmin) {
                window.location.href = '/'
            }
        }, []
    )


    const { TabPane } = Tabs;

    return (
            <div className="mt-3 ml-3 mr-3 mb-5 bs">
                <h1 className="text-center"><b>ADMIN PANEL</b></h1>
                <Tabs defaultActiveKey="1" >
                    <TabPane tab="Servicios" key="1">
                        <Servicioscreen/>
                    </TabPane>
                    <TabPane tab="Agenda" key="2">
                        <AgendaScreen/>
                    </TabPane>
                    <TabPane tab="Reportes" key="3">
                        <ReporteScreen/>
                    </TabPane>
                    <TabPane tab="Usuarios" key="4">
                        <UsersListScreen/>
                    </TabPane>
                </Tabs>
            </div>
    )

}

export default AdminScreen;



