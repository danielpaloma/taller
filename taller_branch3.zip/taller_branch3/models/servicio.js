const mongoose = require('mongoose');

const servicioSchema = mongoose.Schema({

    nombreServicio : {
        type : String,
        required : true
    },

    descripcion : {
        type : String,
        required : true
    },

    costo : {
        type : Number,
        required : true
    },

    //In hours to complete service
    duracion : {
        type : Number,
        required : true
    },

    //Estado : (disponible "true" / no disponible "false")
    estado : {
        type : Boolean,
        required : true
    } ,

    imageUrls : [],

    

}, {
    timestamps : true,
} )

//TO CREATE MODEL : THIS PARAMETERS
//collection name (MONGODB collection) , schema name (created here)
const servicioModel = mongoose.model('servicios', servicioSchema)

module.exports = servicioModel