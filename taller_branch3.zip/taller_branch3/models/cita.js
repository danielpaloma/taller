const mongoose = require('mongoose');

const citaSchema = mongoose.Schema({
    //fecha is stored as String, moment converts to string
    fecha : {
        type : String,
        required : true
    },

    hora : {
        type : String,
        required : true
    },

    placa : {
        type : String,
        required : true
    },

    servicio : {
        type : String,
        required : true
    },

    mecanico : {
        type : String,
        required : true
    },

    estado : {
        type : String,
        required : true
    }

})

//collection name and schema
const citaModel = mongoose.model('citas', citaSchema)

module.exports = citaModel;