const express = require("express");
const router = express.Router();
const mongoose = require('mongoose');

const Cita = require('../models/cita')


//CRUD METHODS
//1. CREATE (guardar reserva)
router.post("/guardarCita", async (req, res) => {

    //destructured data received from Frontend
    const {
        fecha,
        hora,
        placa,
        servicio,
        mecanico,
        estado
    } = req.body

    try {
        const nuevaCita = new Cita({
            fecha,
            hora,
            placa,
            servicio,
            mecanico,
            estado
        })

        const cita = await nuevaCita.save()
        res.send('Cita agregada exitosamente')
    } catch (error) {
        return res.status(400).json({ error })

    }
})

//2. EDIT (editar cita)
router.put("/editarCita", async (req, res) => {
    const dataToUpdate = {
        fecha: req.body.fecha,
        hora: req.body.hora,
        placa:req.body.placa,
        servicio: req.body.servicio,
        mecanico : req.body.mecanico,
        estado: req.body.estado
    }
    
    try {

        const citaEditada = await Cita.findByIdAndUpdate(
            req.body.idcita, dataToUpdate, {new: true})
            
        res.send('Cita EDITADA exitosamente')
    } catch (error) {
        return res.status(400).json({ error })

    }
})

//3. DELETE
router.delete("/deleteReserva/:deletedReservaId", async(req,res)=>{
    try {
        await Cita.findByIdAndRemove(
            req.params.deletedReservaId, 
            (err, deletedItem) =>{
                if (err) return res.status(500).send(err);
                const response = {
                    message : "Reserva borrada exitosamente",
                    id : deletedItem._id
                };
                return res.status(200).send(response);
            })
    } catch (error) {
        
    }
})

//4. READ ALL APPOINTMENTS
router.get("/getCitas", async (req, res) => {

    try {
        const citas = await Cita.find({})
        return res.send(citas);
    } catch (error) {
        return res.status(400).json({ message: error })
    }


});


router.post("/getCitaById", async (req, res) => {

    const idcita = req.body.idcita
    try {
        const cita = await Cita.findOne({ _id: idcita })
        console.log(cita)
        return res.send(cita);
    } catch (error) {
        return res.status(400).json({ message: error })
    }


});

router.post("/getCitaByUserName", async (req, res) => {
    const mecanico = req.body.mecanico

    try {
        const asignaciones = await Cita.find({ mecanico: mecanico })
        res.send(asignaciones)
    } catch (error) {
        return res.status(400).json({ error })

    }
})

router.post("/cancelarCita", async (req, res) => {

    const citaid = req.body.citaid

    try {
        const reserva = await Cita.findOne({ _id: citaid })
        reserva.estado = 'Cancelado'
        await reserva.save()

        res.send(reserva)
    } catch (error) {
        return res.status(400).json({ message: error })
    }

})

//Editar Estado (reservado, reparado,completado,etc)
router.put("/editarEstadoCita", async (req, res) => {

    const dataToUpdate = {
        fecha: req.body.fecha,
        hora: req.body.hora,
        placa: req.body.placa,
        servicio: req.body.servicio,
        mecanico: req.body.mecanico,
        estado: req.body.estado
    }

    try {
        const reservaEditada = await Cita.findByIdAndUpdate(
            req.body.idreserva, dataToUpdate, {new: true})
            
            res.send('Estado de Cita editado exitosamente en la BD')


    } catch (error) {
        return res.status(400).json({ message: error })
    }

})

module.exports = router;