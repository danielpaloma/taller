const express = require("express");
const router = express.Router();

const Servicio = require('../models/servicio')


//CRUD METHODS
//1.CREATE
router.post("/nuevoServicio", async(req, res) => {

    const newItem = new Servicio({
        nombreServicio: req.body.nombreServicio,
        descripcion: req.body.descripcion,
        costo: req.body.costo,
        duracion: req.body.duracion,
        estado: req.body.estado
    })

    //console.log(newItem)
    //res.send('item recibido')

    await newItem.save(err => {
        if (err) return res.status(500).send(err)
        return res.status(200).send(newItem)
    })
})

//2.EDIT 
router.put("/editarServicio", async(req,res)=>{
    const dataToUpdate = {
        nombreServicio: req.body.nombreServicio,
        descripcion: req.body.descripcion,
        costo: req.body.costo,
        duracion: req.body.duracion,
        estado: req.body.estado
    } 
    
    try {
       const servicioEditado = await Servicio.findByIdAndUpdate(
        req.body.idservicio, dataToUpdate, {new: true})
        
        res.send('Item editado exitosamente en la BD')

    
    } catch (error) {
        return res.status(400).json({ error })
    }
      
})

//3. DELETE ITEM
router.delete("/deleteService/:deletedServiceId", async(req,res)=>{
    try {
        await Servicio.findByIdAndRemove(
            req.params.deletedServiceId, 
            (err, deletedItem) =>{
                if (err) return res.status(500).send(err);
                const response = {
                    message : "Servicio borrado exitosamente",
                    id : deletedItem._id
                };
                return res.status(200).send(response);
            })
    } catch (error) {
        
    }
})



router.get("/getServicios", async (req, res) => {

    try {
        const servicios = await Servicio.find({})
        return res.send(servicios);
    } catch (error) {
        return res.status(400).json({ message: error })
    }


});


router.post("/getServicioById", async (req, res) => {

    const idservicio = req.body.idservicio
    try {
        const servicio = await Servicio.findOne({ _id: idservicio })
        console.log(servicio)
        return res.send(servicio);
    } catch (error) {
        return res.status(400).json({ message: error })
    }


});

module.exports = router;